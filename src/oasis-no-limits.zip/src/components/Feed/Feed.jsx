import { useState, useEffect, useCallback } from 'react'
import { useInView } from 'react-intersection-observer'
import { PostCard } from '../PostCard/PostCard'
import { InlineLoader, Skeleton } from '../ui/Loading'
import { supabase } from '../../lib/supabase'
import { FiAlertCircle } from 'react-icons/fi'
import './Feed.css'

const ITEMS_PER_PAGE = 10

export function Feed({ userId = null }) {
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [hasMore, setHasMore] = useState(true)
  const [page, setPage] = useState(0)
  
  const { ref, inView } = useInView({
    threshold: 0,
    rootMargin: '100px',
  })

  const fetchPosts = useCallback(async (pageNum, isRefresh = false) => {
    try {
      setError(null)
      
      const from = pageNum * ITEMS_PER_PAGE
      const to = from + ITEMS_PER_PAGE - 1

      let query = supabase
        .from('posts')
        .select(`
          *,
          profiles (
            id,
            username,
            full_name,
            avatar_url
          ),
          likes (user_id),
          comments (count)
        `, { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(from, to)

      if (userId) {
        query = query.eq('user_id', userId)
      }

      const { data, error: fetchError, count } = await query

      if (fetchError) {
        throw new Error(fetchError.message)
      }

      // Transform data
      const transformedPosts = data?.map(post => ({
        ...post,
        liked_by_current_user: post.likes?.some(l => l.user_id === post.user_id) || false,
        like_count: post.likes?.length || 0,
        comment_count: post.comments?.[0]?.count || 0
      })) || []

      setPosts(prev => isRefresh ? transformedPosts : [...prev, ...transformedPosts])
      setHasMore(transformedPosts.length === ITEMS_PER_PAGE && posts.length + transformedPosts.length < count)
    } catch (err) {
      console.error('Error fetching posts:', err)
      setError('Errore nel caricamento dei post')
    } finally {
      setLoading(false)
    }
  }, [userId, posts.length])

  // Initial load and refresh
  useEffect(() => {
    setLoading(true)
    fetchPosts(0, true)
  }, [userId])

  // Infinite scroll
  useEffect(() => {
    if (inView && hasMore && !loading) {
      const nextPage = page + 1
      setPage(nextPage)
      fetchPosts(nextPage)
    }
  }, [inView, hasMore, loading])

  const handleDelete = (postId) => {
    setPosts(prev => prev.filter(p => p.id !== postId))
  }

  const handleUpdate = (updatedPost) => {
    setPosts(prev => prev.map(p => 
      p.id === updatedPost.id ? { ...p, ...updatedPost } : p
    ))
  }

  if (loading && posts.length === 0) {
    return (
      <div className="feed">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="feed-skeleton">
            <Skeleton height={80} radius="var(--border-radius)" />
            <div style={{ padding: '1.5rem' }}>
              <Skeleton height={100} radius="var(--border-radius)" />
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <div className="feed-error">
        <FiAlertCircle size={48} />
        <p>{error}</p>
        <button onClick={() => { setError(null); fetchPosts(0, true); }}>
          Riprova
        </button>
      </div>
    )
  }

  return (
    <div className="feed">
      {posts.length === 0 ? (
        <div className="feed-empty">
          <p>Nessun post ancora.</p>
          <p>Condividi qualcosa per iniziare!</p>
        </div>
      ) : (
        <>
          {posts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              onDelete={handleDelete}
              onUpdate={handleUpdate}
            />
          ))}
          
          {hasMore && (
            <div ref={ref} className="feed-load-more">
              <InlineLoader text="Caricamento altri post..." />
            </div>
          )}
        </>
      )}
    </div>
  )
}
