import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { Feed } from '../../components/Feed/Feed'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { Card, CardBody } from '../../components/ui/Card'
import { InlineLoader } from '../../components/ui/Loading'
import { FiUserPlus, FiUserMinus, FiMapPin, FiCalendar } from 'react-icons/fi'
import { format } from 'date-fns'
import { it } from 'date-fns/locale'
import toast from 'react-hot-toast'
import './Profile.css'

export function ProfilePage() {
  const { userId } = useParams()
  const { user: currentUser, profile: currentProfile } = useAuth()
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isFollowing, setIsFollowing] = useState(false)
  const [followersCount, setFollowersCount] = useState(0)
  const [followingCount, setFollowingCount] = useState(0)

  const isOwnProfile = currentUser?.id === userId

  useEffect(() => {
    fetchProfile()
    checkFollowing()
    fetchFollowCounts()
  }, [userId])

  const fetchProfile = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single()

      if (error) throw error
      setProfile(data)
    } catch (error) {
      console.error('Error fetching profile:', error)
      toast.error('Errore nel caricamento del profilo')
    } finally {
      setLoading(false)
    }
  }

  const checkFollowing = async () => {
    if (!currentUser) return
    
    try {
      const { data } = await supabase
        .from('follows')
        .select('*')
        .eq('follower_id', currentUser.id)
        .eq('following_id', userId)
        .single()

      setIsFollowing(!!data)
    } catch (error) {
      setIsFollowing(false)
    }
  }

  const fetchFollowCounts = async () => {
    try {
      const { count: followers } = await supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('following_id', userId)

      const { count: following } = await supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('follower_id', userId)

      setFollowersCount(followers || 0)
      setFollowingCount(following || 0)
    } catch (error) {
      console.error('Error fetching follow counts:', error)
    }
  }

  const handleFollow = async () => {
    if (!currentUser) {
      toast.error('Devi accedere per seguire')
      return
    }

    try {
      if (isFollowing) {
        await supabase
          .from('follows')
          .delete()
          .eq('follower_id', currentUser.id)
          .eq('following_id', userId)
        setIsFollowing(false)
        setFollowersCount(prev => prev - 1)
        toast.success('Non segui più questo utente')
      } else {
        await supabase
          .from('follows')
          .insert([{ follower_id: currentUser.id, following_id: userId }])
        setIsFollowing(true)
        setFollowersCount(prev => prev + 1)
        toast.success('Ora segui questo utente')
        
        // Create notification
        await supabase.from('notifications').insert([{
          user_id: userId,
          type: 'follow',
          from_user_id: currentUser.id,
          message: `${currentProfile?.full_name || currentProfile?.username} ha iniziato a seguirti`
        }])
      }
    } catch (error) {
      toast.error("Errore durante l'operazione")
    }
  }

  if (loading) {
    return (
      <div className="profile-loading">
        <InlineLoader text="Caricamento profilo..." />
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="profile-error">
        <h2>Utente non trovato</h2>
        <p>Questo profilo non esiste o è stato rimosso.</p>
      </div>
    )
  }

  return (
    <div className="profile-page">
      <Card className="profile-header-card">
        <CardBody>
          <div className="profile-header">
            <Avatar
              src={profile?.avatar_url}
              alt={profile?.full_name || profile?.username}
              size="xl"
            />
            
            <div className="profile-info">
              <h1 className="profile-name">{profile?.full_name || profile?.username}</h1>
              {profile?.username && (
                <p className="profile-username">@{profile.username}</p>
              )}
              
              {profile?.bio && (
                <p className="profile-bio">{profile.bio}</p>
              )}

              <div className="profile-meta">
                {profile?.location && (
                  <span className="profile-meta-item">
                    <FiMapPin size={14} />
                    {profile.location}
                  </span>
                )}
                <span className="profile-meta-item">
                  <FiCalendar size={14} />
                  Membro da {format(new Date(profile.created_at), 'MMM yyyy', { locale: it })}
                </span>
              </div>

              <div className="profile-stats">
                <div className="profile-stat">
                  <span className="profile-stat-value">{followersCount}</span>
                  <span className="profile-stat-label">Follower</span>
                </div>
                <div className="profile-stat">
                  <span className="profile-stat-value">{followingCount}</span>
                  <span className="profile-stat-label">Seguiti</span>
                </div>
              </div>

              {!isOwnProfile && (
                <Button
                  variant={isFollowing ? 'outline' : 'primary'}
                  onClick={handleFollow}
                  className="profile-follow-btn"
                >
                  {isFollowing ? (
                    <>
                      <FiUserMinus size={18} />
                      Non seguire più
                    </>
                  ) : (
                    <>
                      <FiUserPlus size={18} />
                      Segui
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </CardBody>
      </Card>

      <section className="profile-posts">
        <h2 className="profile-posts-title">Post</h2>
        <Feed userId={userId} />
      </section>
    </div>
  )
}
