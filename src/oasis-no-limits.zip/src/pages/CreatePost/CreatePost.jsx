import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { Textarea } from '../../components/ui/Input'
import { Button } from '../../components/ui/Button'
import { Card, CardBody, CardHeader } from '../../components/ui/Card'
import { FiImage, FiX } from 'react-icons/fi'
import toast from 'react-hot-toast'
import './CreatePost.css'

export function CreatePostPage() {
  const [content, setContent] = useState('')
  const [image, setImage] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  
  const { user, profile } = useAuth()
  const navigate = useNavigate()

  const handleImageSelect = (e) => {
    const file = e.target.files[0]
    if (!file) return

    // Validate file
    if (!file.type.startsWith('image/')) {
      toast.error("Devi selezionare un' immagine")
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("L' immagine deve essere inferiore a 5MB")
      return
    }

    setImage(file)
    setImagePreview(URL.createObjectURL(file))
  }

  const removeImage = () => {
    setImage(null)
    setImagePreview(null)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!content.trim() && !image) {
      toast.error("Scrivi qualcosa o aggiungi un' immagine")
      return
    }

    setLoading(true)

    try {
      let imageUrl = null

      // Upload image if present
      if (image) {
        setUploading(true)
        const fileExt = image.name.split('.').pop()
        const fileName = `${user.id}/${Date.now()}.${fileExt}`
        
        const { error: uploadError } = await supabase.storage
          .from('post-images')
          .upload(fileName, image)

        if (uploadError) throw uploadError

        const { data: { publicUrl } } = supabase.storage
          .from('post-images')
          .getPublicUrl(fileName)

        imageUrl = publicUrl
        setUploading(false)
      }

      // Create post
      const { error: postError } = await supabase
        .from('posts')
        .insert([{
          user_id: user.id,
          content: content.trim(),
          image_url: imageUrl
        }])

      if (postError) throw postError

      toast.success('Post pubblicato!')
      navigate('/')
    } catch (error) {
      console.error('Error creating post:', error)
      toast.error(error.message || 'Errore nella pubblicazione del post')
    } finally {
      setLoading(false)
      setUploading(false)
    }
  }

  return (
    <div className="create-post-page">
      <Card className="create-post-card">
        <CardHeader>
          <h1>Crea un post</h1>
        </CardHeader>
        <CardBody>
          <form onSubmit={handleSubmit} className="create-post-form">
            <div className="create-post-content">
              <div className="create-post-avatar">
                <img 
                  src={profile?.avatar_url || '/default-avatar.png'} 
                  alt={profile?.full_name || 'User'}
                />
              </div>
              <Textarea
                placeholder="Cosa stai pensando?"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={4}
                className="create-post-textarea"
              />
            </div>

            {imagePreview && (
              <div className="create-post-image-preview">
                <img src={imagePreview} alt="Preview" />
                <button type="button" className="remove-image-btn" onClick={removeImage}>
                  <FiX size={20} />
                </button>
              </div>
            )}

            <div className="create-post-actions">
              <label className="create-post-image-btn">
                <FiImage size={20} />
                <span>Foto</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageSelect}
                  hidden
                />
              </label>

              <div className="create-post-submit">
                <Button 
                  type="submit" 
                  disabled={loading || uploading}
                  loading={loading || uploading}
                >
                  Pubblica
                </Button>
              </div>
            </div>
          </form>
        </CardBody>
      </Card>
    </div>
  )
}
