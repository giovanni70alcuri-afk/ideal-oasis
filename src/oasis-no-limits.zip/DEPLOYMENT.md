# ===========================================
# OASIS NO LIMITS - Guida Deployment
# ===========================================

Questa guida spiega come mettere online il social network OASIS NO LIMITS
utilizzando Supabase come backend e Vercel come hosting.

## PREREQUISITI

- Account GitHub (https://github.com)
- Account Supabase (https://supabase.com)
- Account Vercel (https://vercel.com)
- Node.js 18+ installato localmente

---

## PARTE 1: SUPABASE SETUP

### 1.1 Crea progetto Supabase

1. Vai su https://supabase.com e accedi
2. Clicca "New Project"
3. Compila:
   - Name: `oasis-no-limits`
   - Database password: genera una password sicura
   - Region: scegli quella piu' vicina a te
4. Clicca "Create new project"
5. Attendi che il progetto sia pronto (~2 minuti)

### 1.2 Configura Database

1. Nel menu laterale, vai su **SQL Editor**
2. Clicca "New query"
3. Copia tutto il contenuto dal file `supabase/schema.sql`
4. Incolla nella query e clicca "Run"
5. Verifica che non ci siano errori

### 1.3 Configura Storage

1. Nel menu laterale, vai su **Storage**
2. Clicca "New bucket"
3. Nome: `post-images`
4. Spunta "Public bucket"
5. Clicca "Create bucket"

### 1.4 Ottieni credenziali

1. Vai su **Settings > API**
2. Copia:
   - Project URL -> sara' `VITE_SUPABASE_URL`
   - anon public key -> sara' `VITE_SUPABASE_ANON_KEY`

---

## PARTE 2: GITHUB SETUP

### 2.1 Crea repository

1. Vai su https://github.com e accedi
2. Clicca "+" > "New repository"
3. Nome: `oasis-no-limits`
4. Description: `Social network - OASIS NO LIMITS`
5. Public/Private: Public
6. Non inizializzare con README (lo abbiamo gia')
7. Clicca "Create repository"

### 2.2 Carica il codice

Esegui questi comandi nel terminale:

```bash
# Entra nella cartella del progetto
cd /workspace

# Inizializza git (se non gia' fatto)
git init

# Aggiungi tutti i file
git add .

# Commit
git commit -m "Initial commit: OASIS NO LIMITS social network"

# Connetti al repository GitHub
git remote add origin https://github.com/TUO_USERNAME/oasis-no-limits.git

# Sostituisci TUO_USERNAME con il tuo username GitHub

# Push
git branch -M main
git push -u origin main
```

---

## PARTE 3: VERCEL DEPLOYMENT

### 3.1 Connetti Vercel a GitHub

1. Vai su https://vercel.com e accedi
2. Clicca "Add New..." > "Project"
3. Seleziona il repository `oasis-no-limits` da GitHub
4. Clicca "Import"

### 3.2 Configura Environment Variables

Nella pagina di deploy, scorri fino a "Environment Variables" e aggiungi:

| Nome | Valore |
|------|--------|
| VITE_SUPABASE_URL | `https://your-project-id.supabase.co` |
| VITE_SUPABASE_ANON_KEY | `la-tua-anon-key` |

**Importante:** Sostituisci con i valori reali del tuo progetto Supabase.

### 3.3 Deploy

1. Clicca "Deploy"
2. Attendi il completamento (~2-3 minuti)
3. Vedrai un URL tipo: `https://oasis-no-limits.vercel.app`
4. Clicca l'URL per verificare che funzioni

### 3.4 Aggiornamenti futuri

Quando fai modifiche al codice:

```bash
git add .
git commit -m "Descrizione delle modifiche"
git push
```

Vercel fara' il redeploy automaticamente.

---

## PARTE 4: VERIFICA FUNZIONAMENTO

### 4.1 Test locali (opzionale)

Prima del deployment, puoi testare localmente:

```bash
# Copia il file env
cp .env.example .env

# Modifica .env con le tue credenziali Supabase

# Avvia server locale
npm run dev
```

Vai su http://localhost:3000 per testare.

### 4.2 Checklist post-deploy

- [ ] La home page si carica
- [ ] Posso registrarmi / accedere
- [ ] Posso creare un post
- [ ] Posso mettere like
- [ ] Posso commentare
- [ ] Posso seguire altri utenti
- [ ] Le immagini si caricano correttamente
- [ ] Le notifiche funzionano

---

## RISOLUZIONE PROBLEMI

### Errore: "Supabase credentials missing"

1. Verifica che le Environment Variables siano configurate su Vercel
2. Controlla che i valori siano corretti (senza spazi o virgolette extra)
3. Fai un redeploy dopo averle aggiunte

### Errore: "Failed to fetch posts"

1. Verifica che le tabelle siano state create nel database
2. Controlla che le RLS policies siano state applicate
3. Verifica che il bucket storage esista

### Errore: "Storage upload failed"

1. Verifica che il bucket `post-images` sia pubblico
2. Controlla le dimensioni dell'immagine (max 5MB)
3. Verifica i formati supportati (jpg, png, gif, webp)

### Errori CORS

Se vedi errori CORS, assicurati che l'URL di Vercel sia
autorizzato in Supabase:
1. Vai su Supabase > Settings > API
2. In "URL Configurations", aggiungi l'URL di Vercel

---

## STRUTTURA PROGETTO

```
oasis-no-limits/
├── src/
│   ├── components/
│   │   ├── ui/          # Button, Input, Card, Avatar, Loading
│   │   ├── Layout/      # Layout principale
│   │   ├── Navbar/      # Navigazione
│   │   ├── Feed/        # Feed posts
│   │   ├── PostCard/    # Card singolo post
│   │   └── ProtectedRoute/
│   ├── pages/
│   │   ├── Home/        # Home page con feed
│   │   ├── Auth/        # Login e Signup
│   │   ├── Profile/     # Profilo utente
│   │   ├── CreatePost/  # Crea nuovo post
│   │   ├── PostDetail/  # Dettaglio post + commenti
│   │   └── Notifications/
│   ├── context/
│   │   └── AuthContext.jsx  # Gestione autenticazione
│   ├── lib/
│   │   └── supabase.js  # Client Supabase
│   ├── App.jsx
│   └── main.jsx
├── supabase/
│   └── schema.sql       # Database schema
├── .env.example
├── package.json
├── vite.config.js
└── vercel.json
```

---

## CONTATTI E SUPPORTO

Per problemi o domande:
- GitHub Issues del progetto
- Documentazione Supabase: https://supabase.com/docs
- Documentazione Vercel: https://vercel.com/docs

---

**OASIS NO LIMITS v1.0.0**
Social network senza limiti.
